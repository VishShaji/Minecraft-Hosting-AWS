// AWS Cognito Configuration
const COGNITO_CONFIG = {
    UserPoolId: 'ap-south-1_q5k72bACv',
    ClientId: '7q8kiupti9mbmtk42b3o0vlgu'
};

// API Endpoints
const API_CONFIG = {
    baseUrl: 'https://p4lx4rz6ik.execute-api.ap-south-1.amazonaws.com',
    endpoints: {
        status: '/server-status',
        start: '/start-server',
        stop: '/stop-server'
    }
};

let userSession = null;

// Initialize the Amazon Cognito Auth
const userPool = new AmazonCognitoIdentity.CognitoUserPool(COGNITO_CONFIG);

// Handle Login
async function handleLogin(email, password) {
    return new Promise((resolve, reject) => {
        const authData = {
            Username: email,
            Password: password
        };

        const authDetails = new AmazonCognitoIdentity.AuthenticationDetails(authData);
        const userData = {
            Username: email,
            Pool: userPool
        };

        const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

        cognitoUser.authenticateUser(authDetails, {
            onSuccess: (session) => {
                userSession = session;
                document.getElementById('loginSection').style.display = 'none';
                document.getElementById('serverControls').style.display = 'block';
                updateServerStatus();
                resolve(session);
            },
            onFailure: (err) => {
                console.error('Login failed:', err);
                alert('Login failed: ' + err.message);
                reject(err);
            }
        });
    });
}

// Handle Sign Up
async function handleSignUp(email, password) {
    return new Promise((resolve, reject) => {
        const attributeList = [
            new AmazonCognitoIdentity.CognitoUserAttribute({
                Name: 'email',
                Value: email
            })
        ];

        userPool.signUp(email, password, attributeList, null, (err, result) => {
            if (err) {
                console.error('Sign up failed:', err);
                alert('Sign up failed: ' + err.message);
                reject(err);
                return;
            }
            alert('Sign up successful! Please check your email for verification code.');
            resolve(result);
        });
    });
}

// Handle Verification
async function handleVerification(email, code) {
    return new Promise((resolve, reject) => {
        const userData = {
            Username: email,
            Pool: userPool
        };

        const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

        cognitoUser.confirmRegistration(code, true, (err, result) => {
            if (err) {
                console.error('Verification failed:', err);
                alert('Verification failed: ' + err.message);
                reject(err);
                return;
            }
            alert('Verification successful! You can now login.');
            resolve(result);
        });
    });
}

// API Calls with Authentication
async function makeAuthenticatedRequest(endpoint, method = 'GET') {
    if (!userSession) {
        throw new Error('No active session');
    }

    const token = userSession.getIdToken().getJwtToken();
    
    try {
        const response = await fetch(API_CONFIG.baseUrl + endpoint, {
            method: method,
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('API request failed:', error);
        throw error;
    }
}

// Server Control Functions
async function updateServerStatus() {
    try {
        const status = await makeAuthenticatedRequest(API_CONFIG.endpoints.status);
        const statusElement = document.getElementById('serverStatus');
        const ipElement = document.getElementById('serverIP');
        
        statusElement.textContent = status.status || 'UNKNOWN';
        if (status.ip) {
            ipElement.textContent = `${status.ip}:${status.port || '25565'}`;
            document.getElementById('connectionDetails').style.display = 'block';
        } else {
            ipElement.textContent = 'Not Available';
            document.getElementById('connectionDetails').style.display = 'none';
        }
        
        updateButtons(status.status);
    } catch (error) {
        console.error('Failed to update status:', error);
        document.getElementById('serverStatus').textContent = 'Error';
    }
}

async function startServer() {
    try {
        const startButton = document.getElementById('startButton');
        startButton.disabled = true;
        
        await makeAuthenticatedRequest(API_CONFIG.endpoints.start, 'POST');
        updateServerStatus();
    } catch (error) {
        console.error('Failed to start server:', error);
        alert('Failed to start server: ' + error.message);
    } finally {
        startButton.disabled = false;
    }
}

async function stopServer() {
    try {
        const stopButton = document.getElementById('stopButton');
        stopButton.disabled = true;
        
        await makeAuthenticatedRequest(API_CONFIG.endpoints.stop, 'POST');
        updateServerStatus();
    } catch (error) {
        console.error('Failed to stop server:', error);
        alert('Failed to stop server: ' + error.message);
    } finally {
        stopButton.disabled = false;
    }
}

function updateButtons(status) {
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    
    if (status === 'RUNNING') {
        startButton.disabled = true;
        stopButton.disabled = false;
    } else if (status === 'TERMINATED' || status === 'NOT_FOUND') {
        startButton.disabled = false;
        stopButton.disabled = true;
    } else {
        startButton.disabled = true;
        stopButton.disabled = true;
    }
}

// Copy server address to clipboard
function copyConnectionDetails() {
    const ipElement = document.getElementById('serverIP');
    navigator.clipboard.writeText(ipElement.textContent)
        .then(() => alert('Server address copied to clipboard!'))
        .catch(err => console.error('Failed to copy:', err));
}

// Initialize status updates
document.addEventListener('DOMContentLoaded', () => {
    // Check if user is already logged in
    const cognitoUser = userPool.getCurrentUser();
    if (cognitoUser) {
        cognitoUser.getSession((err, session) => {
            if (err) {
                console.error('Session check failed:', err);
                return;
            }
            if (session.isValid()) {
                userSession = session;
                document.getElementById('loginSection').style.display = 'none';
                document.getElementById('serverControls').style.display = 'block';
                updateServerStatus();
            }
        });
    }

    // Start periodic status updates
    setInterval(updateServerStatus, 30000); // Update every 30 seconds
});
