const config = {
    cognito: {
        UserPoolId: 'ap-south-1_q5k72bACv', 
        ClientId: '7q8kiupti9mbmtk42b3o0vlgu',      
        Region: 'ap-south-1'            
    },
    api: {
        baseUrl: 'https://p4lx4rz6ik.execute-api.ap-south-1.amazonaws.com/prod'
};
